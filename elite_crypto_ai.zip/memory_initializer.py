print('✅ Ready')
