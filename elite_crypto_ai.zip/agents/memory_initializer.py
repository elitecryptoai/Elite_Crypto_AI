import os
import json
from datetime import datetime

MEMORY_DIR = "memory"

FILES = {
    "forecast_outcomes.json": {},
    "strategy_memory.json": {},
    "fusion_memory.json": {},
    "source_trust_log.json": {},
    "decision_log.json": [],
    "prompt_scores.json": {},
    "meta_summary.json": {
        "created": datetime.utcnow().isoformat(),
        "total_forecasts": 0,
        "total_strategies": 0,
        "best_combo": None
    }
}

def init_memory():
    os.makedirs(MEMORY_DIR, exist_ok=True)
    for file, initial in FILES.items():
        path = os.path.join(MEMORY_DIR, file)
        if not os.path.exists(path):
            with open(path, "w") as f:
                json.dump(initial, f, indent=2)
    print(f"🧠 memory/ initialized with {len(FILES)} core files.")

if __name__ == "__main__":
    init_memory()
