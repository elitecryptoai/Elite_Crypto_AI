import os
import json
from datetime import datetime
from agents.utils.llm import query_llm_with_fallback

MEMORY_FILE = "memory/prompt_scores.json"
NEW_PROMPT_FILE = "memory/generated_prompts.json"

class PromptEvolver:
    def __init__(self):
        self.memory = {}
        self.prompts = []
        self.new_prompts = []

    def load(self):
        if os.path.exists(MEMORY_FILE):
            with open(MEMORY_FILE, "r") as f:
                self.memory = json.load(f)

        # fallback static if nothing exists yet
        if not self.memory:
            self.prompts = [
                {"id": "v1", "template": "basic forecast format", "win_rate": 0.56},
                {"id": "v2", "template": "forecast + quant stats", "win_rate": 0.74},
                {"id": "v3", "template": "forecast + strategy overlay", "win_rate": 0.62}
            ]
        else:
            for pid, data in self.memory.items():
                self.prompts.append({
                    "id": pid,
                    "template": f"PROMPT FORMAT: {pid}",
                    "win_rate": data.get("avg_win", 0)
                })

    def update_scores(self):
        for p in self.prompts:
            pid = p["id"]
            if pid not in self.memory:
                self.memory[pid] = {
                    "runs": 0,
                    "avg_win": 0,
                    "history": []
                }
            entry = self.memory[pid]
            entry["runs"] += 1
            entry["history"].append(p["win_rate"])
            entry["history"] = entry["history"][-30:]  # keep last 30 runs
            entry["avg_win"] = round(sum(entry["history"]) / len(entry["history"]), 4)

    def generate_new_prompt(self):
        print("🤖 Generating new prompt using LLM...")
        prompt = (
            "You are an elite AI prompt architect. Based on the following data about prompt win rates, "
            "suggest 1–2 new prompt formats that could outperform the existing ones. "
            "Your output should be a JSON list of prompt formats with ids and descriptions.\n"
            f"Prompt Score Memory:\n{json.dumps(self.memory, indent=2)[:1500]}"
        )
        try:
            result = query_llm_with_fallback(prompt)
            data = json.loads(result)
            if isinstance(data, list):
                self.new_prompts = data
        except Exception as e:
            print(f"❌ GPT generation failed: {e}")

    def save(self):
        with open(MEMORY_FILE, "w") as f:
            json.dump(self.memory, f, indent=2)
        if self.new_prompts:
            with open(NEW_PROMPT_FILE, "w") as f:
                json.dump(self.new_prompts, f, indent=2)
        print(f"🧠 PromptEvolver updated scores for {len(self.memory)} prompt formats.")
        if self.new_prompts:
            print(f"✨ {len(self.new_prompts)} new prompt formats generated and saved.")

    def run(self):
        print("🧬 PromptEvolver running with GPT generation enabled...")
        self.load()
        self.update_scores()
        self.generate_new_prompt()
        self.save()

if __name__ == "__main__":
    PromptEvolver().run()
