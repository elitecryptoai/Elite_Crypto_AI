import os
import json
from datetime import datetime

from utils.memory_writer import update_forecast_memory, update_strategy_memory, update_decision_log

LOGS = {
    "forecasts": "intel/forecast_signals.json",
    "fused": "intel/fused_forecast_signals.json",
    "performance": "intel/performance_metrics.json",
    "strategies": "logs/strategy_feedback.json",
    "decisions": "logs/execution_log.json"
}

class MemoryManager:
    def __init__(self):
        self.forecasts = {}
        self.fused = {}
        self.performance = {}
        self.strategies = {}
        self.decisions = []

    def safe_load(self, path):
        if os.path.exists(path):
            with open(path, "r") as f:
                try:
                    return json.load(f)
                except:
                    return {}
        return {}

    def load_inputs(self):
        self.forecasts = self.safe_load(LOGS["forecasts"])
        self.fused = self.safe_load(LOGS["fused"])
        self.performance = self.safe_load(LOGS["performance"])
        self.strategies = self.safe_load(LOGS["strategies"])
        self.decisions = self.safe_load(LOGS["decisions"])

    def update_all_memory(self):
        update_forecast_memory(self.fused, self.performance)
        update_strategy_memory(self.strategies, self.performance)
        update_decision_log(self.decisions)
        print("🧠 MemoryManager updated all memory layers.")

    def run(self):
        print("📘 MemoryManager starting...")
        self.load_inputs()
        self.update_all_memory()

if __name__ == "__main__":
    MemoryManager().run()
