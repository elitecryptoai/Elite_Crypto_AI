import os
import json
from datetime import datetime

MEMORY_DIR = "memory"

FILES = {
    "forecast_outcomes.json": {},
    "strategy_memory.json": {},
    "decision_log.json": []
}

def load_memory_file(name):
    path = os.path.join(MEMORY_DIR, name)
    if os.path.exists(path):
        with open(path, "r") as f:
            return json.load(f)
    return FILES[name]

def save_memory_file(name, data):
    path = os.path.join(MEMORY_DIR, name)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def update_forecast_memory(fused_forecasts, performance):
    memory = load_memory_file("forecast_outcomes.json")
    for token, data in fused_forecasts.items():
        result = performance.get(token, {})
        memory[token] = memory.get(token, [])
        memory[token].append({
            "timestamp": datetime.utcnow().isoformat(),
            "source": data.get("source"),
            "confidence": data.get("confidence_score"),
            "adjusted_score": data.get("adjusted_score"),
            "hit_rate": result.get("hit_rate"),
            "drawdown": result.get("drawdown"),
            "sharpe": result.get("sharpe")
        })
    save_memory_file("forecast_outcomes.json", memory)


def update_strategy_memory(strategy_feedback, performance):
    memory = load_memory_file("strategy_memory.json")
    for token, data in strategy_feedback.items():
        strategy = data.get("top_strategy")
        perf = performance.get(token, {})
        if strategy:
            memory[strategy] = memory.get(strategy, [])
            memory[strategy].append({
                "token": token,
                "timestamp": datetime.utcnow().isoformat(),
                "hit_rate": perf.get("hit_rate"),
                "sharpe": perf.get("sharpe"),
                "drawdown": perf.get("drawdown")
            })
    save_memory_file("strategy_memory.json", memory)


def update_decision_log(decisions):
    memory = load_memory_file("decision_log.json")
    for d in decisions:
        d["recorded_at"] = datetime.utcnow().isoformat()
        memory.append(d)
    memory = memory[-300:]  # keep last 300 entries
    save_memory_file("decision_log.json", memory)
