import subprocess
import time
from datetime import datetime

# 🧠 Autopilot: Smart agent runner based on time of day, market mood, and memory

AGENT_ORDER = [
    "search_agent",
    "forecast_agent",
    "strategy_agent",
    "forecast_fusion_x",
    "manager_agent",
    "execution_agent",
    "memory_manager",
    "prompt_evolver"
]

# Optional: you could dynamically skip agents later based on memory/conditions

def run_agent(name):
    path = f"agents/{name}.py"
    print(f"🧩 Running: {name}.py @ {datetime.now().isoformat()}")
    try:
        subprocess.run(["python", path], check=True)
    except subprocess.CalledProcessError as e:
        print(f"❌ Agent {name} failed: {e}")
    time.sleep(1)

class AutoPilot:
    def run_all(self):
        print("🚀 AutoPilot launching full system...")
        for agent in AGENT_ORDER:
            run_agent(agent)
        print("✅ AutoPilot completed full stack.")

if __name__ == "__main__":
    AutoPilot().run_all()
