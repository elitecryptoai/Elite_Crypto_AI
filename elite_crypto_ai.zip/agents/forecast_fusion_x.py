import os
import json
from datetime import datetime

FORECAST_FILE = "intel/forecast_signals.json"
MARKET_FILE = "intel/market_status.json"
PERFORMANCE_FILE = "intel/performance_metrics.json"
FUSED_OUTPUT = "intel/fused_forecast_signals.json"
FUSION_LOG = "logs/forecast_fusion_log.json"

class ForecastFusionX:
    def __init__(self):
        self.forecasts = {}
        self.market = {}
        self.performance = {}
        self.fused = {}
        self.source_scores = {}

    def load_inputs(self):
        def safe_load(path):
            if os.path.exists(path):
                with open(path, "r") as f:
                    return json.load(f)
            return {}

        self.forecasts = safe_load(FORECAST_FILE)
        self.market = safe_load(MARKET_FILE)
        self.performance = safe_load(PERFORMANCE_FILE)

    def score_sources(self):
        for token, sources in self.forecasts.items():
            for source, data in sources.items():
                if token not in self.performance:
                    continue
                result = self.performance[token]
                hit = 1 if result.get("hit_rate", 0) > 0.5 else 0
                if source not in self.source_scores:
                    self.source_scores[source] = {"hits": 0, "total": 0}
                self.source_scores[source]["hits"] += hit
                self.source_scores[source]["total"] += 1

        for source in self.source_scores:
            h = self.source_scores[source]["hits"]
            t = self.source_scores[source]["total"]
            self.source_scores[source]["accuracy"] = round(h / t, 4) if t else 0.0

    def fuse(self):
        for token, sources in self.forecasts.items():
            best_score = -1
            best_source = None
            for source, data in sources.items():
                confidence = data.get("confidence_score", 0)
                accuracy = self.source_scores.get(source, {}).get("accuracy", 0.5)
                adjusted = confidence * accuracy
                if adjusted > best_score:
                    best_score = adjusted
                    best_source = source
            if best_source:
                self.fused[token] = sources[best_source]
                self.fused[token]["source"] = best_source
                self.fused[token]["adjusted_score"] = round(best_score, 4)

    def save_outputs(self):
        with open(FUSED_OUTPUT, "w") as f:
            json.dump(self.fused, f, indent=2)
        with open(FUSION_LOG, "a") as f:
            f.write(json.dumps({
                "timestamp": datetime.utcnow().isoformat(),
                "scores": self.source_scores
            }) + "\n")
        print(f"[FusionX] ✅ {len(self.fused)} forecasts fused and scored.")

    def run(self):
        print("🔮 ForecastFusionX: Meta-aware fusion running...")
        self.load_inputs()
        self.score_sources()
        self.fuse()
        self.save_outputs()

if __name__ == "__main__":
    ForecastFusionX().run()
