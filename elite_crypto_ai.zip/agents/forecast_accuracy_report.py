import os
import json
from datetime import datetime, timedelta

HISTORY_FILE = "logs/forecast_history.json"
REPORT_FILE = "logs/forecast_vs_actual_report.json"
SUMMARY_FILE = "logs/forecast_model_scores.json"

class ForecastVsActualReporter:
    def __init__(self):
        self.history = []
        self.report = {}
        self.summary = {}

    def load_history(self):
        if os.path.exists(HISTORY_FILE):
            with open(HISTORY_FILE, "r") as f:
                self.history = json.load(f)

    def generate(self):
        cutoff = datetime.utcnow() - timedelta(days=5)
        report_data = {}
        model_stats = {}

        for entry in self.history:
            try:
                ts = datetime.fromisoformat(entry.get("timestamp", ""))
                if ts < cutoff:
                    token = entry.get("token", "UNKNOWN")
                    forecast = entry.get("forecast", {})
                    label = forecast.get("forecast_label", "neutral").lower()
                    model = forecast.get("model_used", "unknown")
                    price_in = entry.get("entry_price", 0)

                    # Simulated price_out logic
                    price_out = price_in * 1.05 if label == "bullish" else price_in * 0.95 if label == "bearish" else price_in * 1.01
                    real_change = (price_out - price_in) / price_in if price_in else 0

                    result = "correct" if (
                        (label == "bullish" and real_change > 0.02) or
                        (label == "bearish" and real_change < -0.02) or
                        (label == "neutral" and abs(real_change) < 0.02)
                    ) else "wrong"

                    report_entry = {
                        "model": model,
                        "forecast": label,
                        "price_in": price_in,
                        "price_out": price_out,
                        "result": result,
                        "change_pct": round(real_change * 100, 2),
                        "timestamp": entry.get("timestamp")
                    }

                    report_data.setdefault(token, []).append(report_entry)

                    if model not in model_stats:
                        model_stats[model] = {"correct": 0, "wrong": 0}
                    model_stats[model][result] += 1
            except Exception as e:
                print(f"⚠️ Error in processing forecast entry: {e}")

        self.report = report_data
        self.summary = model_stats

    def save(self):
        os.makedirs(os.path.dirname(REPORT_FILE), exist_ok=True)
        with open(REPORT_FILE, "w") as f:
            json.dump(self.report, f, indent=2)
        with open(SUMMARY_FILE, "w") as f:
            json.dump(self.summary, f, indent=2)
        print(f"✅ Forecast vs Actual report saved: {REPORT_FILE}")
        print(f"📊 Model accuracy summary saved: {SUMMARY_FILE}")

    def run(self):
        print("📊 Generating Forecast vs Actual Accuracy Report...")
        self.load_history()
        self.generate()
        self.save()

if __name__ == "__main__":
    ForecastVsActualReporter().run()
