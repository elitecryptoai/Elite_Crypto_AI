# utils/google_trends.py

import random

def fetch_trend_score(token):
    # Fake mock — return 0 to 100 popularity
    return random.randint(10, 90)
