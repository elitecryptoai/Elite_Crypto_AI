# utils/signal_utils.py

import random

def get_volume_signal(symbol):
    return random.uniform(0.5, 2.5)  # stub

def get_trend_strength(symbol):
    return random.uniform(0.0, 1.0)  # stub

def get_social_buzz(symbol):
    return random.uniform(0.0, 1.0)  # stub
