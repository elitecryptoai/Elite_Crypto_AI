# utils/sources/uniswap.py

import random

def get_price_from_uniswap(symbol):
    # Fake mock price from Uniswap
    return round(random.uniform(1, 5000), 2)
