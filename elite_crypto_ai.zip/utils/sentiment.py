# utils/sentiment.py

import random

def get_twitter_sentiment(token):
    # Fake NLP-style polarity score
    return round(random.uniform(-1.0, 1.0), 2)
