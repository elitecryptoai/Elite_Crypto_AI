# Volatility Compression Breakout
def run(price_data):
    return 0.09
