# Auto Profit Lock and Pullback Exit
def run(price_data):
    return 0.01
