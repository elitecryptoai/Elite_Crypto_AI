# Breakout Volume Trend
def run(price_data):
    return 0.08
