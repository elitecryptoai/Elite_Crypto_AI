# Dollar Cost Averaging Strategy
def run(price_data):
    return 0.03
