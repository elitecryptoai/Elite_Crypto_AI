# Multi-MA Ride Strategy
def run(price_data):
    return 0.05
