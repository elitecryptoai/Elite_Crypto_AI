# Hard-Floor Exit Trigger
def run(price_data):
    return 0.00
