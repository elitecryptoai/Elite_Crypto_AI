# Low-Risk Stack Builder
def run(price_data):
    return 0.02
