# VWAP Snapback Reversion
def run(price_data):
    return 0.03
