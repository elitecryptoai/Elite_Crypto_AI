# Dip-Only Dollar Cost Averaging
def run(price_data):
    return 0.04
