# RSI Swing Reversal
def run(price_data):
    return 0.06
